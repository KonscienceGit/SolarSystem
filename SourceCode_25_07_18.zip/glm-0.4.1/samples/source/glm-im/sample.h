#ifndef __SAMPLE_H__
#define __SAMPLE_H__

void Begin(int Width, int Height);
void End();
void Render(float Time);

#endif//__SAMPLE_H__
